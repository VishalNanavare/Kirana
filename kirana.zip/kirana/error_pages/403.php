<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Material Design Bootstrap</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  <!-- Bootstrap core CSS -->
  <link href="../css/bootstrap.min.css" rel="stylesheet">
  <link href="../css/custom.css" rel="stylesheet">

  <!-- Your custom styles (optional) -->
  <link href="../css/style.css" rel="stylesheet">
<!------ Include the above in your HEAD tag ---------->
<style>
#main {
    height: 100vh;
}
  </style>
<div class="d-flex justify-content-center align-items-center" id="main">
    <h1 class="mr-3 pr-3 align-top border-right inline-block align-content-center">403 : Forbidden</h1>
    <div class="inline-block align-middle w-25">
      <img src="http://localhost/VIP_Door_Services/img/logo.png" class="w-75">
      <h2 class="font-weight-normal lead" id="desc">You dont have permission to access this source.</h2>
      <h6 class="font-weight-normal" id="link"><a href='http://localhost/VIP_Door_Services/index'>Go back</a></h6>
    </div>
</div>


  <!-- JQuery -->
  <script type="text/javascript" src="../js/jquery-3.4.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="../js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="../js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
