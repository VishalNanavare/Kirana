var basepath = window.location.protocol+'//'+window.location.hostname+window.location.pathname;
var current_full_path = window.location.href;
var loadUI = '';

$(document).ready(function(){
    $(".se-pre-con").delay(2000).fadeOut("fast");
    //load the page user loaded already
    var loadhash = windowhash();
    if(!empty(loadhash)){
        loadui(loadhash);
    }
});

  // Or with jQuery

  $(document).ready(function(){
    $('.sidenav').sidenav();
  });

function empty(str){
    var chk = Array();
    chk = [0 ,'' ,false];
    for(var i = 0; i < chk.length; i++){
        if(str == chk[i] || typeof str === 'undefined'){
            return true;
        }else{
            return false;
        }
    }
}

function test(){
    $.ajax({
        type: "POST",
        url: basepath+"?event=test",
        data: '',
        dataType: "json",
        success: function(data){
            console.log(data['test1']);
            //show_modal("success_modal", "this is test!!!");
        },
        error:function(){

        }
    });
}

function clearconsole() {
    //console.log(window.console);
    if(window.console || window.console.firebug) {
     console.clear();
    }
}

function handle_load(){
    var currenthash = windowhash();
    var onload_func = window[currenthash+"_onload"];

    //chk is there any onload function
    if(typeof onload_func === 'function'){
        onload_func();
    }
}

function windowhash(){
    var hash = window.location.hash;
    if(hash.substring(0, 1) == '#'){
        hash = hash.substring(1);
    }
    return hash;
}

function test1_onload(){
  //  alert('test1');
}

function test2_onload(){
  // alert('test2');
}

async function loadui(id){
    $(".se-pre-con").show();
    await sleep(500);
    $('div .khidki').each(function(){
        var div_id = $(this).attr('id');
        if(div_id.includes(id)){
            $(this).show();
        }else{
            $(this).hide();
        }
    });
    handle_load();
    $(".se-pre-con").hide();
}

function select_all(ele){
    var status = $(ele).is(":checked"); 
    $('td input[type=checkbox]').each(function(){
        $(this).prop('checked', status);
    });
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function show_modal(id,msg = '', dismiss = true){
    if(!empty(msg)){
        $('#'+id+" .modal-content #modal-msg").html(msg);
    }

    const elem = document.getElementById(id);
    const instance = M.Modal.init(elem, {dismissible: dismiss});
    instance.open();
}