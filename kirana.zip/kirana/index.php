<?php
/*
* author ZAKURA 
* Started in aug 2019 
* Copyright 2019 easyfy
*/
include('./main/include.php');
if(!defined('EASYFY')){
  die('Hackers not allowed!!');
}
session_start();
global $event,$db,$theme;
$load_index = $_GET['index'];
if(!is_ajax()){
  if(empty($load_index)){
    compile('./UI/index.html');
  }else{
    loadui('default');
    $event = $_GET['event'];
    switch($event){
      case 'register':
        loadui('register');
        return;
      break;
      default:
        loadui('index');
      break;
    }
  }
}else{
  $event = $_GET['event'];
  switch($event){
    case 'test':
      loadscript('default');
      return;
    break;
  }
}

?>