<?php
/*
* author ZAKURA 
* Started in aug 2019 
* Copyright 2019 easyfy
*/
if(!defined('EASYFY')){
  die('Hackers not allowed!!');
}

global $theme;
loadscript('default');

function _default(){
  global $theme, $done, $error, $otp, $otp_flag;
  echo'<body>
  <div class="se-pre-con">
    </div>
  <div id="error_modal" class="modal">
    <div class="modal-content">
      <h5 class="red-text darken-1 valign-wrapper"><i class="small material-icons">cancel</i>&nbsp;ERROR!</h5>
      <p id="modal-msg"></p>
    </div>
    <div class="modal-footer">
      <a href="javascript:void(0)" class="modal-close waves-effect waves-green btn-flat">Close</a>
    </div>
  </div>
  <div id="success_modal" class="modal">
    <div class="modal-content">
      <h5 class="green-text darken-1 valign-wrapper"><i class="small material-icons">check_circle</i>&nbsp;Success!</h5>
      <p id="modal-msg"></p>
    </div>
    <div class="modal-footer">
      <a href="javascript:void(0)" class="modal-close waves-effect waves-green btn-flat">OK</a>
    </div>
  </div>';
  $theme->_header();
}
_default();
?>