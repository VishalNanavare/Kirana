<?php
/*
* author ZAKURA 
* Started in aug 2019 
* Copyright 2019 easyfy
*/
if(!defined('EASYFY')){
  die('Hackers not allowed!!');
}

global $theme;
loadscript('register');

function register(){
  global $theme, $done, $error, $otp, $otp_flag;
  echo'
  <div id="otp_modal" class="modal">
    <div class="modal-content">
      <h4>OTP</h4>
      <p id="modal-msg">An otp is send on you mobile number if mobile number was wromg than resend the data.</p>
      <form method = "post" name="otp_form">
        <div class="col s12 l6 m6">
          <div class="input-field inline w-100 my-3">
            <input id="otp" name="otp" type="text" class="validate" required '.chk_text_post('otp').'>
            <label for="otp">Enter OTP</label>
            <span class="helper-text" data-error="Enter your OTP"></span>
          </div>
        </div>
        <div class="row">
          <div class="col s12 l6 m6">
            <button class="btn bd light-blue darken-3 waves-effect waves-light" type="submit" name="send_otp">Send
              <i class="material-icons right">send</i>
            </button>
          </div>
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <a href="javascript:void(0)" class="modal-close waves-effect waves-green btn-flat">Close</a>
    </div>
  </div>

  <!--Actual  contatiner starts here-->
  <div class="container mt-5">
    <div class="row">
      <div class="col l12 m6 s12 offset-m3">
        <div class="card">
            <div class="card-content">
                <h5 class="hide-on-med-and-down">Register Now!</h5>
                <h6 class="show-on-medium-and-down hide-on-med-and-up">Register Now!</h6>
                <form method="post" action="#"><br>
                  <div class="row">
                    <div class="col s12 l6 m6">
                      <div class="input-field inline w-100 my-3">
                        <input id="fname" name="fname" type="text" class="validate" required '.chk_text_post('fname').'>
                        <label for="fname">First Name</label>
                        <span class="helper-text" data-error="Enter your first name"></span>
                      </div>
                    </div>
                    <div class="col s12 l6 m6">
                      <div class="input-field inline w-100 my-3">
                        <input id="lname" name="lname" type="text" class="validate" required '.chk_text_post('lname').'>
                        <label for="lname">Last Name</label>
                        <span class="helper-text" data-error="Enter your last name"></span>
                      </div>
                    </div>
                    <div class="col s12 l6 m6">
                      <div class="input-field inline w-100 my-3">
                        <input id="email" name="email" type="email" '.chk_text_post('email').'>
                        <label for="email">Email</label>
                        <span class="helper-text"></span>
                      </div>
                    </div>
                    <div class="col s12 l6 m6">
                      <div class="input-field inline w-100 my-3">
                        <input id="mob_num" name="mob_num" type="text" class="validate" required '.chk_text_post('mob_num').'>
                        <label for="mob_num">Mobile Number</label>
                        <span class="helper-text" data-error="Enter your mobile number"></span>
                      </div>
                    </div>
                    <div class="col s12 l6 m6">
                      <div class="input-field inline w-100 my-3">
                        <input id="password" name="password" type="password" class="validate" required '.chk_text_post('password').'>
                        <label for="password">Password</label>
                        <span class="helper-text" data-error="Enter your password"></span>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col s12 l6 m6">
                      <button class="btn bd light-blue darken-3 waves-effect waves-light" type="submit" name="register">Submit
                        <i class="material-icons right">send</i>
                      </button>
                    </div>
                  </div>
                </form>
            </div>
        </div>
      </div>
    </div>
  </div>';
  if(!empty($otp)){
    show_popup('otp_modal');
  }
  if(!empty($error)){
    $msg = error_handle($error);
    show_popup('error_modal',$msg);
  }
  if(empty($otp_flag)){
    show_popup('success_modal', '<div align="center" class="mb-3 center-align"><h6 id="content" >We are getting some things ready for you!<h6></div> \
    <div class="progress"> \
      <div class="determinate" style="width: 0%"></div> \
  </div>');
    echo'<script>var $progress = $(".progress");
    var $progressBar = $(".determinate");
    var progresscount = 0;
var timeout = 100;
var incerment =.5;
var maxprogress = 140;
var redirect=0;
var content = Array();
content[25] = "Building your custom portal!";
content[50] = "Custom portal is ready!";
content[75] = "Securing your data and creating your profile!";
content[100] = "Creating your billing system";
content[130] = "Thankyou for registering with us!";
$(document).ready(function(){
setTimeout(function(){
  interval = setInterval(function(){
    progresscount += incerment;
    if(progresscount < maxprogress)
    {
      $progressBar.css("width",progresscount + "%");
      $("#content").html(content[progresscount]);
    }
    else
    {
      $progress.css("display", "none");
      clearInterval(interval);
      window.location = basepath;
      redirect = 1;
    }
  }, 100);
  3
},timeout);
});
</script>';
  }
}

register();
?>