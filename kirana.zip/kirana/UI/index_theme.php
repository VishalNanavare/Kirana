<?php
/*
* author ZAKURA 
* Started in aug 2019 
* Copyright 2019 easyfy
*/
if(!defined('EASYFY')){
  die('Hackers not allowed!!');
}

global $theme;
loadscript('index');

function index(){
  global $theme;
  echo'
  <!--Actual  contatiner starts here-->
  <div class="container mt-5">
    <div class="row">
      <div class="col l12 m6 s12 offset-m3">
        <div class="card">
          TEST 123
        </div>
      </div>
    </div>
  </div>
 
</body>';
}
index();
?>