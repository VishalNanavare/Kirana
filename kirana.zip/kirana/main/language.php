<?php
/*
* author ZAKURA 
* Started in aug 2019 
* Copyright 2019 easyfy
*/
if(!defined('EASYFY')){
    die('Hackers not allowed!!');
  }
  global $lang;
  $lang['pro_name'] = 'Easy<span class="text-success">fy</span>'; 
  $lang['sign_in'] = 'Sign In'; 
  $lang['email_label'] = 'Email';
  $lang['password_label'] = 'Password';
  ?>