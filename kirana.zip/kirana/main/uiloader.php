<?php
/*
* author ZAKURA 
* Started in aug 2019 
* Copyright 2019 easyfy
*/
if(!defined('EASYFY')){
    die('Hackers not allowed!!');
}
$ui = array('login','dashboard');
foreach($ui as $value){
    loadui($value);
  }
?>