<?php
/*
* author ZAKURA 
* Started in aug 2019 
* Copyright 2019 easyfy
*/
if(!defined('EASYFY')){
    die('Hackers not allowed!!');
}
global $theme;
class theme
{
    function __construct()
    {
        
    }

    function _header(){
      global $lang;
        echo '
        <div class="navbar-fixed">
        <nav class="light-blue darken-1">
          <div class="nav-wrapper">
            <a href="#!" class="brand-logo">Logo</a>
            <a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
            <ul class="right hide-on-med-and-down">
              <li><a href="sass.html" class="">Sass</a></li>
              <li><a href="badges.html">Components</a></li>
              <li><a href="collapsible.html">Javascript</a></li>
              <li><a href="mobile.html">Mobile</a></li>
            </ul>
          </div>
        </nav>
      </div>
      <ul class="sidenav" id="mobile-demo">
      <li><div class="user-view">
         <div class="background">
           <img src="images/office.jpg">
         </div>
         <a href="#user"><img class="circle" src="images/yuna.jpg"></a>
         <a href="#name"><span class="white-text name">John Doe</span></a>
         <a href="#email"><span class="white-text email">jdandturk@gmail.com</span></a>
       </div></li>
       <li><a href="#!"><i class="material-icons">cloud</i>First Link With Icon</a></li>
       <li><a href="#!">Second Link</a></li>
       <li><div class="divider"></div></li>
       <li><a class="subheader">Subheader</a></li>
       <li><a class="waves-effect" href="#!">Third Link With Waves</a></li>
     </ul>
        ';
        }

    function _footer()
    {
        global $db,$path,$lang;
        echo'<!-- Footer -->
        <footer class="pagefooter font-small bg-dark pt-4 ">
        
        <!-- Footer Links -->
        <div class="container-fluid text-center text-md-left">
        
            <!-- Grid row -->
            <div class="row">
        
            <!-- Grid column -->
            <div class="col-md-6 mt-md-0 mt-3">
                <!-- Content -->
                <h5>'.$lang['pro_name'].'</h5>
                <p>Here you can use rows and columns here to organize your footer content.</p>
            </div>
            <!-- Grid column -->
        
            <hr class="clearfix w-100 d-md-none pb-3">
        
            <!-- Grid column -->
            <div class="col-md-3 mb-md-0 mb-3">
        
                <!-- Links -->
                <h5 class="text-uppercase">Links</h5>
        
                <ul class="list-unstyled">
                    <li>
                    <a href="#!">Link 1</a>
                    </li>
                    <li>
                    <a href="#!">Link 2</a>
                    </li>
                    <li>
                    <a href="#!">Link 3</a>
                    </li>
                    <li>
                    <a href="#!">Link 4</a>
                    </li>
                </ul>
        
                </div>
                <!-- Grid column -->
        
                <!-- Grid column -->
                <div class="col-md-3 mb-md-0 mb-3">
        
                <!-- Links -->
                <h5 class="text-uppercase">Links</h5>
        
                <ul class="list-unstyled">
                    <li>
                    <a href="#!">Link 1</a>
                    </li>
                    <li>
                    <a href="#!">Link 2</a>
                    </li>
                    <li>
                    <a href="#!">Link 3</a>
                    </li>
                    <li>
                    <a href="#!">Link 4</a>
                    </li>
                </ul>
        
                </div>
                <!-- Grid column -->
        
            </div>
            <!-- Grid row -->
        
        </div>
        <!-- Footer Links -->
        
        <!-- Copyright -->
        <div class="footer-copyright text-center py-3">© 2019 Copyright:
            <a href="https://mdbootstrap.com/education/bootstrap/"> easyfy.com</a>
        </div>
        </footer>
        <!-- Footer -->';
    }

    function poperror($msg, $event = 0, $admin='')
    {
      global $universal;
      echo
      '<script>
        show_modal("error_modal", "'.$msg.'");
      </script>
      '; 
      if(!empty($event)){
        echo'<script>
        $("#error_modal").on("hide.bs.modal", function(e) {
          window.location.href="'.$universal['website'].'/'.$admin.'index?event='.$event.'";
        });
      </script>';
      }
    }

    function popwarning($msg, $event = 0, $admin='')
    {
      global $universal;
      echo
      '<script>
        show_modal("warning_modal", "'.$msg.'");
      </script>
      ';  
      if(!empty($event)){
        echo'<script>
        $("#warning_modal").on("hide.bs.modal", function(e) {
          window.location.href="'.$universal['website'].'/'.$admin.'index?event='.$event.'";
        });
      </script>';
      }
    }

    function popsuccess($msg, $event = 0, $admin='')
    {
      global $universal;
      echo
      '<script>
        show_modal("success_modal", "'.$msg.'");
      </script>
      ';
      if(!empty($event)){
        echo'<script>
        $("#success_modal").on("hide.bs.modal", function(e) {
          window.location.href="'.$universal['website'].'/'.$admin.'index?event='.$event.'";
        });
      </script>';
      }
    }
}
$theme = new theme();


?>