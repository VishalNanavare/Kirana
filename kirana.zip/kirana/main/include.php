<?php
/*
* author ZAKURA 
* Started in aug 2019 
* Copyright 2019 Elision Infotech
*/
  global $db,$theme,$is_admin;

  $include = array();
  require 'PHPMailer-master/PHPMailerAutoload.php';
  
  //All functions
 array_push($include, 'functions', 'language', 'theme');

 //Additional scripts
 array_push($include, 'settings');

 //Load Other Files
 array_push($include,'default');
  
foreach($include as $value){
  if(file_exists('./main/'.$value.'.php')){
    include('./main/'.$value.'.php');
  }else{
    if($is_admin){
      include('../main/'.$value.'.php');
    }
  }
}
if(!is_ajax()){
  loadcss();
  loadjs();
}

?>



