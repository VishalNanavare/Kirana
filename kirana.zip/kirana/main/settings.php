<?php
/*
* author ZAKURA 
* Started in aug 2019 
* Copyright 2019 Elision Infotech
*/
if(!defined('EASYFY')){
    die('Hackers not allowed!!');
}
global $path,$universal,$lang,$admin,$database;

$path['css'] = 'css/';
$path['js'] = 'js/';
$path['img'] = 'img/';

//universal
$universal['logo'] = $path['img'].'logo.png';
$universal['copyright'] = '© 2020 Copyright : <a href="#">'.$lang['pro_name'] .'</a>';
$universal['website'] = 'http://localhost/VIP_Door_Services';

//admin
$admin['uname'] = "admin@admin.com";
$admin['pass'] = "21232f297a57a5a743894a0e4a801fc3";

//database
$database['servername'] = 'localhost';
$database['uname'] = 'root';
$database['pass'] = 'mysql';
$database['dbname'] = 'kirana';

//mail
$universal['mail_email'] = 'vipdoorservices@gmail.com';
$universal['mail_pass'] = '9029395540';

?>