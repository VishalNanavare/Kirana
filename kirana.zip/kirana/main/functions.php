<?php
/*
* author ZAKURA 
* Started in aug 2019 
* Copyright 2019 Elision Infotech
*/
define('EASYFY',1);
if(!defined('EASYFY')){
    die('Hackers not allowed!!');
}

function loadjs(){
  global $path;
  echo'<script type="text/javascript" src="'.$path['js'].'jquery-3.4.1.min.js"></script>
  <script type="text/javascript" src="'.$path['js'].'materialize.js"></script>
  <script type="text/javascript" src="'.$path['js'].'custom.js"></script>';
}

function loadcss(){
  global $path, $lang;
  echo '<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>'.$lang['pro_name'].'</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  <link href="'.$path['css'].'custom.css" rel="stylesheet">
  <link href="'.$path['css'].'materialize.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">';
}

function _redirect($event, $admin=''){
  global $universal;
  if (!headers_sent()){
      header('Location: '.$universal['website'].'/'.$admin.'index?event='.$event);
      exit;
    }else{
      echo '<script type="text/javascript">';
      echo 'window.location.href="'.$universal['website'].'/'.$admin.'index?event='.$event.'";';
      echo '</script>';
      echo '<noscript>';
      echo '<meta http-equiv="refresh" content="0;url='.$universal['website'].'/'.$admin.'index?event='.$event.'" />';
      echo '</noscript>'; 
      exit;
    }
}

function encrypt_token($name){
  return base64_encode(rand(10,100).'_'.$name.'_'.md5($name).rand(10,100));
}

function decrypt_token($name){
  $tmp = @base64_decode($name);
  $tmp = @explode('_', $tmp);
  $tmp = $tmp[1];
  return $tmp;
}

function validatetoken($tok){
  $dec = decrypt_token($tok);
  if(empty($dec)){
    return false;
  }
  return true;
}

function set_url_session($name, $URI){
  global $old_uri;
  $old_uri = $URI;
  $old_uri = explode('event=', $old_uri);
  $old_uri = $old_uri[1];
  $_SESSION[$name] = $old_uri;
}

function check_admin_login($URI = ''){
  global $old_uri, $theme, $event;
  if(!empty($URI)){
    if(!is_ajax()){
      set_url_session('admin_old_uri', $URI);
    }
    if((!isset($_COOKIE['admin_login']) && !isset($_COOKIE['admin_remember_me']))){
      if(!isset($_SESSION['admin_login'])){
        _redirect('admin_login', 'admin/');
      }
    }
  }else{
    if((!isset($_COOKIE['admin_login']) && !isset($_COOKIE['admin_remember_me']))){
      if(!isset($_SESSION['admin_login'])){
        return false;
      }
    }
    return true;
  }
  
}

function check_user_login($URI = ''){
  global $old_uri, $theme, $event, $chk_user_login;
  if(!empty($URI)){
    if(!is_ajax()){
      set_url_session('user_old_uri', $URI);
    }
    if((!isset($_COOKIE['user_login']) && !isset($_COOKIE['user_remember_me']))){
      if(!isset($_SESSION['user_login'])){
        unset($chk_user_login);
        _redirect('dashboard');
      }
    }
  }else{
    if((!isset($_COOKIE['user_login']) && !isset($_COOKIE['user_remember_me']))){
      if(!isset($_SESSION['user_login'])){
        return false;
      }
    }
    return true;
  }
  
}

function log_message($name, $msg){
  $dt = date('Y-m-d H:i:s', time());
  file_put_contents($name, "\n [".$dt."]".$msg.PHP_EOL , FILE_APPEND | LOCK_EX);
} 

function loadscript($name){
    if(!@include('./script/'.$name.'.php')){
        return false;
    }
    return true;
}

function loadui($name){
  $f = file_get_contents('./ui/'.$name.'_theme.php');
  if(strpos($f, "!defined('EASYFY')")){
    return include_once('./ui/'.$name.'_theme.php');
  }else{
    die("hacker not allowed");
  }
}

function is_ajax() {
  return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
}

//text field post
function chk_text_post($name, $val = ''){
  if(isset($_POST[$name])&&!empty($_POST[$name])){
    return 'value="'.$_POST[$name].'"';
  }elseif(!empty($val)){
    return 'value="'.$val.'"';
  }
}

function show_popup($id, $msg = '', $dismiss = true){
  echo'<script>
    show_modal(\''.$id.'\', \''.$msg.'\', '.$dismiss.');
  </script>';
}

//select post 
function chk_op_post($name, $val = ''){
  if((isset($_POST[$name])&&!empty($_POST[$name]))){
    if($_POST[$name] == $val){
      return 'selected="selected"';
    }
  }else{
    if($name == $val){
      return 'selected="selected"';
    }
  }
}

function chk_check_radio_post($name, $val = ''){
  if((isset($_POST[$name])&&!empty($_POST[$name])) || !empty($val)){
    return 'checked="checked"';
  }
}

function textarea_post($name, $val = ''){
  if(isset($_POST[$name])&&!empty($_POST[$name])){
    return $_POST[$name];
  }elseif(!empty($val)){
    return $val;
  }
}

function error_handle($error = array()){
  $str = '<ul>';
  foreach($error as $v){
      $str .= '<li>'.$v.'</li>';           
  }
  $str .='</ul>';

  return $str;
}

function pass_encrypt($pass){
  return base64_encode(md5($pass).base64_encode($pass));
}

//This function compiles the index.html
/*
langaue syntax l[]
path syntax p[]
universal syntax u[]
function sysntax f_[]_f
single quate _{}_
*/
function compile($_path){
  global $lang, $path, $theme, $db, $universal;

  $content = file_get_contents('./UI/index.html');

  //First change languages
  foreach($lang as $k => $v){
    $content = str_replace('l['.$k.']', $v, $content);
  }

  //replace variables path
  foreach($path as $k => $v){
    $content = str_replace('p['.$k.']', $v, $content);
  }

  //replace variables universal
  foreach($universal as $k => $v){
    $content = str_replace('u['.$k.']', $v, $content);
  }

  //replace ' quotes
  $content = str_replace('_{', '\\\'', $content);
  $content = str_replace('}_', '\\\'', $content);
  
  $content = str_replace('f_[', '\'.', $content);
  $content = str_replace(']_f', '.\'', $content);

  $content = 'echo \''.$content.'\';';
  eval($content);
}

/*
$fields = array(
    "sender_id" => "FSTSMS",
    "language" => "english",
    "route" => "qt",
    "numbers" => $p_number,
    "message" => "29517",
    "variables" => "{#BB#}",
    "variables_values" => $otp
);
*/
function send_otp($mob_num, $otp){
  $curl = curl_init();
  $fields = array(
    "sender_id" => "FSTSMS",
    "language" => "english",
    "route" => "qt",
    "numbers" => $mob_num,
    "message" => "29517",
    "variables" => "{#BB#}",
    "variables_values" => $otp
  );
  curl_setopt_array($curl, array(
    CURLOPT_URL => "https://www.fast2sms.com/dev/bulk",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYHOST => 0,
    CURLOPT_SSL_VERIFYPEER => 0,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => json_encode($fields),
    CURLOPT_HTTPHEADER => array(
      "authorization: klYYzN1oRv3nHnMVNNwbAFYAL7di1T3bqwPDC5T0ke1tN8gLjMWaiP48cr0u",
      "cache-control: no-cache",
      "accept: */*",
      "content-type: application/json"
    ),
  ));

  $response = curl_exec($curl);
  $err = curl_error($curl);

  curl_close($curl);

  if ($err) {
    return false;
  }
  return true;
}

/*
$param['to']
$param['subject']
$param['body']
*/

function _mail($param){

  global $universal, $error;
  
  $mail = new PHPMailer;

  $mail->isSMTP();  
  $mail->Host = 'smtp.gmail.com';
  $mail->SMTPAuth = true;
  $mail->Username = $universal['mail_email'];
  $mail->Password = $universal['mail_pass'];
  //$mail->SMTPSecure = 'tls'; 
  $mail->SMTPOptions = array(
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
  );
  $mail->Port = 587;  
  $mail->setFrom('from@example.com', 'VIP Door Services');

  $mail->addAddress($param['to']);

  $mail->isHTML(true);

  //attachment
  //$mail->addAttachment('/var/tmp/file.tar.gz');  

  $mail->Subject = $param['subject'];
  $mail->Body    = $param['body'];
  if(!$mail->send()) 
  {
    return false;
    // echo "Mailer Error: " . $mail->ErrorInfo;
  } 
  else 
  {
    return true;
    // echo "Message has been sent successfully";
  }
  
}

//database start
global $db;
class db
{
    function __construct()
    {

    }

    function mconnect()
    {
      global $theme,$database;
      if(!empty($database['dbname'])){
        $db_name = 'dbname='.$database['dbname'];
      }
      try {
        $conn = new PDO('mysql:host='.$database['servername'].';'.$db_name, $database['uname'], $database['pass']);
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        //$theme->popsuccess('connected');
      }             
      catch(PDOException $e){
        die($e->getMessage());
      }
      return $conn;
    }

    function mquery($query, $tokens=array())
    {
      $conn = $this->mconnect();
      $res = $conn->prepare($query);
      if(!empty($tokens)){
        $res->execute($tokens);
      }else{
        $res->execute();
      }
      
      return $res;
    }

    function mfetch_assoc($res)
    {
      $res->setFetchMode(PDO::FETCH_ASSOC);
      $result = $res->fetchAll();
      return $result;
    }

    function mdata_to_table()
    {

    }

    function mdata_to_array()
    {
        
    }
}
$db = new db();
//databse end


?>