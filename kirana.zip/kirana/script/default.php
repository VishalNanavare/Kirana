<?php
/*
* author ZAKURA 
* Started in aug 2019 
* Copyright 2019 Elision Infotech
*/
if(!defined('EASYFY')){
  die('Hackers not allowed!!');
}
global $theme, $event, $path, $error, $done, $db, $database;

if(!is_ajax()){
}else{
  $test['test1'] = "test1234";
  echo json_encode($test);
  return true;
}

?>