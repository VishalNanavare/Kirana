SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Database: `kirana`
--

-- --------------------------------------------------------

--
-- Table structure for table `billing`
--

CREATE TABLE `billing` (
  `bid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `stid` int(11) NOT NULL DEFAULT '0' COMMENT 'staff id',
  `bill_data` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  `udhar` int(11) NOT NULL COMMENT '(partial or full)',
  `tot_price` int(11) NOT NULL,
  `paid_amt` int(11) NOT NULL COMMENT 'will be shown only for partial udhar',
  `balance` int(11) NOT NULL,
  `bill_date` int(14) NOT NULL,
  `pay_op` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `extras` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bill_status`
--

CREATE TABLE `bill_status` (
  `blid` int(11) NOT NULL,
  `bid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `stid` int(11) NOT NULL DEFAULT '0' COMMENT 'staff id',
  `tid` int(11) NOT NULL COMMENT 'transaction id',
  `status` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT '(cancel, udhar,cash, upi)',
  `udhar_type` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT '(partial or full),',
  `ins_time` int(14) NOT NULL,
  `update_time` int(14) NOT NULL,
  `extas` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `pro_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `pro_code` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `pro_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `gst_no` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL COMMENT 'total number of items',
  `qt_unit` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'unit measurement',
  `gst_per` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `proc_pic` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `ins_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `exrtras` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `uid` int(11) NOT NULL COMMENT 'Userid',
  `fname` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Fisrt name',
  `lname` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Last name',
  `email` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Email Address',
  `mob_num` varchar(12) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Mobile Number',
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Paswword',
  `otp_flag` int(11) NOT NULL DEFAULT '0' COMMENT 'This falg is used for sending otp in databse and after correct otp chage it to 1 for verification',
  `shop_flag` int(11) NOT NULL DEFAULT '0' COMMENT 'This flag willbe set if user has atleast one shop =',
  `ins_time` int(14) NOT NULL COMMENT 'The timestamp when user registered',
  `update_time` int(14) NOT NULL COMMENT 'The timestamp when user update',
  `profile_pic` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT 'Proflie picture in array',
  `extras` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT 'Extras column for data if needed'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shops`
--

CREATE TABLE `shops` (
  `sh_id` int(11) NOT NULL COMMENT 'shop ID',
  `uid` int(11) NOT NULL COMMENT 'User ID',
  `sh_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Shop Type',
  `sh_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Shop Name',
  `sh_address` varchar(200) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Shop Address',
  `sh_mob_num` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Address',
  `sh_gst_num` varchar(25) COLLATE utf8_unicode_ci NOT NULL COMMENT 'GST',
  `sh_pic` mediumtext COLLATE utf8_unicode_ci NOT NULL COMMENT 'Picture in array',
  `location` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'lat and long',
  `ins_time` int(14) NOT NULL COMMENT 'The timestamp when user inserted',
  `update_time` int(14) NOT NULL COMMENT 'The timestamp when user updated',
  `extras` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT 'Extras column for data if needed'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `stid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `fname` int(11) NOT NULL,
  `lname` int(11) NOT NULL,
  `email` int(11) DEFAULT NULL,
  `monb_num` int(11) NOT NULL,
  `password` int(11) NOT NULL,
  `address` int(11) NOT NULL,
  `adhar_no` int(11) NOT NULL,
  `pancard_no` int(11) DEFAULT NULL,
  `voter_id` int(11) DEFAULT NULL,
  `role` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `prof_pic` varchar(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `salary` int(11) NOT NULL,
  `ins_time` int(14) NOT NULL,
  `update_time` int(14) NOT NULL,
  `extras` mediumtext COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `tid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `bid` int(11) NOT NULL,
  `stid` int(11) NOT NULL,
  `tran_status` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'cash, cancel, upi',
  `tran_flag` int(11) NOT NULL DEFAULT '0' COMMENT 'This flag to check status of transaction',
  `ins_date` int(14) NOT NULL,
  `extras` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `udhar`
--

CREATE TABLE `udhar` (
  `udid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `bid` int(11) NOT NULL,
  `stid` int(11) NOT NULL DEFAULT '0' COMMENT 'staff id',
  `uuid` int(11) NOT NULL,
  `type` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'partial or full',
  `amt` int(11) NOT NULL,
  `ins_date` int(14) NOT NULL,
  `extras` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `udhar_user`
--

CREATE TABLE `udhar_user` (
  `uuid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `mob_num` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `billing`
--
ALTER TABLE `billing`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `bill_status`
--
ALTER TABLE `bill_status`
  ADD PRIMARY KEY (`blid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `mob_num` (`mob_num`);

--
-- Indexes for table `shops`
--
ALTER TABLE `shops`
  ADD PRIMARY KEY (`sh_id`),
  ADD UNIQUE KEY `sh_gst_num` (`sh_gst_num`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`stid`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`tid`);

--
-- Indexes for table `udhar`
--
ALTER TABLE `udhar`
  ADD PRIMARY KEY (`udid`);

--
-- Indexes for table `udhar_user`
--
ALTER TABLE `udhar_user`
  ADD PRIMARY KEY (`uuid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `billing`
--
ALTER TABLE `billing`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bill_status`
--
ALTER TABLE `bill_status`
  MODIFY `blid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Userid', AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `shops`
--
ALTER TABLE `shops`
  MODIFY `sh_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'shop ID';

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `stid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `udhar`
--
ALTER TABLE `udhar`
  MODIFY `udid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `udhar_user`
--
ALTER TABLE `udhar_user`
  MODIFY `uuid` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;
