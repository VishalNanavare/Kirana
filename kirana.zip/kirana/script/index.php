<?php
/*
* author ZAKURA 
* Started in aug 2019 
* Copyright 2019 easyfy
*/
if(!defined('EASYFY')){
  die('Hackers not allowed!!');
}
global $done, $error, $otp, $otp_flag, $db, $database;
if(!is_ajax()){
  
}



?>