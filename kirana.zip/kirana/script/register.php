<?php
/*
* author ZAKURA 
* Started in aug 2019 
* Copyright 2019 easyfy
*/
if(!defined('EASYFY')){
  die('Hackers not allowed!!');
}
global $done, $error, $otp, $otp_flag, $db, $database;
if(!is_ajax()){
  if(isset($_POST['register'])){
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $mob_num = $_POST['mob_num'];
    $pass = $_POST['password'];

    if(empty($fname)){
        $error[] = 'Enter your first name';
    }
    if(empty($lname)){
        $error[] = 'Enter your last name';
    }
    if(empty($mob_num)){
        $error[] = 'Enter your mobile number';
    }
    if(strlen($mob_num) < 10){
        $error[] = 'Enter your mobile number';
    }
    if(empty($pass)){
        $error[] = 'Enter your password';
    }

    $uppercase = preg_match('@[A-Z]@', $pass);
    $lowercase = preg_match('@[a-z]@', $pass);
    $number    = preg_match('@[0-9]@', $pass);

    if(!$uppercase || !$lowercase || !$number || strlen($pass) < 8) {
        $error[] = 'Password should contain Uppercase ,Lowercase, Number AND length should be 8 or above';
    }

    if(!empty($error)){
        return false;
    }

    $res = $db->mquery('SELECT mob_num FROM profile WHERE mob_num = :mob_num', 
                        array(':mob_num' => $mob_num));
    $rows = $db->mfetch_assoc($res);

    if(!empty($rows[0]['mob_num'])){
        $error[] = 'This mobile number is already registered!!';
        return false;
    }
    
    $_SESSION['details'] = $_POST;
    $_otp = mt_rand(1000,9999);
    $temp_otp = encrypt_token($_otp);
    setcookie('otp', $temp_otp);
    $otp = 1;
    if(!send_otp($mob_num, $_otp)){
      $error[] = 'There was an error while sending otp';
      $otp = 0;
      return false;
    }
  }
  if(isset($_POST['send_otp'])){
    $otp_flag=1;
    $otp=0;
    $tmp_otp = decrypt_token($_COOKIE['otp']);
    if(empty($_POST['otp']) || ($tmp_otp != $_POST['otp'])){
      $error[] = 'OTP you send is invalid!';
      $_POST = $_SESSION['details'];
      $otp_flag=0;
      return false;
    }
    $data = $_SESSION['details'];
    $data['time'] = time();
    $data['password'] = pass_encrypt($data['password']);
    insertit($data);
             
    $database['dbname'] = '';
    $con = $db->mquery('CREATE DATABASE kirana_'.$data['mob_num']);
    $database['dbname'] = 'kirana_'.$data['mob_num'];

    $file = file('./script/kirana.sql');
    $temp = '';
    foreach($file as $k => $v){
      if(preg_match('/--/', $v)) continue;
      $temp .=$v;
    }
    $db->mquery($temp);
    insertit($data);
  }
}

function insertit($data){
    global $db;
    $db->mquery("INSERT INTO profile SET
        fname = :fname,
        lname = :lname,
        email = :email,
        mob_num = :mob_num,
        password = :password,
        otp_flag = :otp_flag,
        ins_time = :ins_time,
        update_time = :update_time", array(
        ':fname' => $data['fname'],
        ':lname' => $data['lname'],
        ':email' => $data['email'],
        ':mob_num' => $data['mob_num'],
        ':password' => $data['password'],
        ':otp_flag' => 1,
        ':ins_time' => $data['time'],
        ':update_time' => $data['time']
        ));
}



?>